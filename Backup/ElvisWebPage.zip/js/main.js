/* =========================================================
   CONFIGURAÇÕES (edite aqui)
   ========================================================= */
// Número do WhatsApp (somente dígitos) + mensagem padrão
const WHATS_NUMBER = "5515997897433";
const WHATS_MSG = encodeURIComponent("Olá Elvis! Vim pelo site e quero agendar uma aula experimental.");
const WHATS_LINK = `https://wa.me/${WHATS_NUMBER}?text=${WHATS_MSG}`;

// Instagram
const INSTA_LINK = "https://www.instagram.com/elvis.godoyy/";

/* =========================================================
   UTILIDADE
   ========================================================= */
const $ = (sel) => document.querySelector(sel);

/* =========================================================
   CTAs GERAIS (links)
   ========================================================= */
$("#btnHeaderWhats").href = WHATS_LINK;
$("#btnMobileWhats").href = WHATS_LINK;
$("#btnHeroWhats").href = WHATS_LINK;
$("#floatWhats").href = WHATS_LINK;
$("#btnCtaFinal").href = WHATS_LINK;
$("#footerWhats").href = WHATS_LINK;

$("#btnHeroInsta").href = INSTA_LINK;
$("#btnSobreInsta").href = INSTA_LINK;
$("#footerInsta").href = INSTA_LINK;

/* Serviços → WhatsApp com mensagem personalizada */
document.querySelectorAll(".service-cta").forEach((btn) => {
    const tipo = btn.getAttribute("data-service") || "Serviço";
    const msg = encodeURIComponent(`Olá Elvis! Vim pelo site e tenho interesse em ${tipo}. Podemos conversar?`);
    btn.href = `https://wa.me/${WHATS_NUMBER}?text=${msg}`;
});

/* =========================================================
   MENU MOBILE
   ========================================================= */
const burger = $("#burger");
const mobileMenu = $("#mobileMenu");
burger.addEventListener("click", () => {
    const open = mobileMenu.hasAttribute("hidden");
    if (open) {
        mobileMenu.removeAttribute("hidden");
        burger.setAttribute("aria-expanded", "true");
    } else {
        mobileMenu.setAttribute("hidden", "");
        burger.setAttribute("aria-expanded", "false");
    }
});
/* Fecha menu ao clicar em um link interno */
mobileMenu.addEventListener("click", (e) => {
    if (e.target.matches("a")) {
        mobileMenu.setAttribute("hidden", "");
        burger.setAttribute("aria-expanded", "false");
    }
});

/* =========================================================
   TEMA: auto → dark → light (salvo no localStorage)
   ========================================================= */
const btnTheme = $("#btnTheme");
const brandLogo = $("#brandLogo");

function applyLogoForTheme(theme) {
    // isDark: se dark explicitamente OU auto com sistema dark
    const isDark = theme === "dark" ||
        (theme === "auto" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    brandLogo.src = isDark ? "assets/img/logo-light.png" : "assets/img/logo-dark.png";
}

// Lê preferência salva
let savedTheme = localStorage.getItem("theme") || "auto";
if (savedTheme !== "auto") document.body.setAttribute("data-theme", savedTheme);
applyLogoForTheme(savedTheme);

// Alterna ao clicar (auto → dark → light → auto)
btnTheme.addEventListener("click", () => {
    const order = ["auto", "dark", "light"];
    const idx = order.indexOf(savedTheme);
    savedTheme = order[(idx + 1) % order.length];

    if (savedTheme === "auto") document.body.removeAttribute("data-theme");
    else document.body.setAttribute("data-theme", savedTheme);

    localStorage.setItem("theme", savedTheme);
    applyLogoForTheme(savedTheme);
});

// Se o sistema muda e estamos em "auto", troca logo
window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
    if ((localStorage.getItem("theme") || "auto") === "auto") applyLogoForTheme("auto");
});

/* =========================================================
   HEADER COM ESTADO AO ROLAR
   ========================================================= */
const siteHeader = $("#siteHeader");
function onScrollHeader() {
    const y = window.scrollY || window.pageYOffset;
    if (y > 12) siteHeader.classList.add("is-scrolled");
    else siteHeader.classList.remove("is-scrolled");
}
onScrollHeader();
window.addEventListener("scroll", onScrollHeader);

/* =========================================================
   NAVEGAÇÃO SUAVE PARA ÂNCORAS
   ========================================================= */
document.querySelectorAll('a[href^="#"]').forEach((a) => {
    a.addEventListener("click", (e) => {
        const id = a.getAttribute("href");
        if (!id || id === "#") return;
        const target = document.querySelector(id);
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    });
});

/* =========================================================
   RODAPÉ: ano automático
   ========================================================= */
const yearEl = $("#year");
if (yearEl) yearEl.textContent = new Date().getFullYear();
